<?php
// --- Database Configuration ---
$dbHost = 'localhost'; // Your database host
$dbUser = 'root';      // Your database username
$dbPass = '';          // Your database password
$dbName = 'company_data'; // Your database name

// --- Establish Connection ---
header("Content-Type: application/json");
$conn = new mysqli($dbHost, $dbUser, $dbPass, $dbName);

if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => "Connection failed: " . $conn->connect_error]);
    exit();
}

// --- API Router ---
$requestBody = json_decode(file_get_contents('php://input'), true);
$action = $requestBody['action'] ?? '';
$table = $requestBody['table'] ?? '';
$data = $requestBody['data'] ?? null;

// Validate table name to prevent SQL injection
$allowedTables = ['resources', 'invoices'];
if (!in_array($table, $allowedTables)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => "Invalid table specified."]);
    exit();
}

function sendResponse($success, $dataOrMessage) {
    if ($success) {
        echo json_encode(['success' => true, 'data' => $dataOrMessage]);
    } else {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => $dataOrMessage]);
    }
    exit();
}

switch ($action) {
    case 'get_all':
        $result = $conn->query("SELECT * FROM `$table` ORDER BY id");
        $items = [];
        while ($row = $result->fetch_assoc()) {
            $items[] = $row;
        }
        sendResponse(true, $items);
        break;

    case 'create':
        $columns = array_keys($data);
        $values = array_map(function($val) use ($conn) {
            return "'" . $conn->real_escape_string($val) . "'";
        }, array_values($data));
        
        $sql = "INSERT INTO `$table` (`" . implode('`, `', $columns) . "`) VALUES (" . implode(', ', $values) . ")";
        
        if ($conn->query($sql) === TRUE) {
            $data['id'] = $conn->insert_id;
            sendResponse(true, $data);
        } else {
            sendResponse(false, "Error: " . $conn->error);
        }
        break;

    case 'update':
        $id = intval($data['id']);
        unset($data['id']);
        $updates = [];
        foreach ($data as $key => $value) {
            $updates[] = "`$key` = '" . $conn->real_escape_string($value) . "'";
        }

        $sql = "UPDATE `$table` SET " . implode(', ', $updates) . " WHERE id = $id";
        
        if ($conn->query($sql) === TRUE) {
            sendResponse(true, ['id' => $id]);
        } else {
            sendResponse(false, "Error: " . $conn->error);
        }
        break;

    default:
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => "Invalid action specified."]);
        break;
}

$conn->close();
?>
