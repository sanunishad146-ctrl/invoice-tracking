-- Create a database named 'company_data' if it doesn't exist
CREATE DATABASE IF NOT EXISTS `company_data`;
USE `company_data`;

-- Table structure for `resources` table
CREATE TABLE `resources` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `source` varchar(255) DEFAULT NULL,
  `customerName` varchar(255) DEFAULT NULL,
  `resourceName` varchar(255) DEFAULT NULL,
  `mode` varchar(50) DEFAULT NULL,
  `recruiter` varchar(255) DEFAULT NULL,
  `joinMonth` varchar(50) DEFAULT NULL,
  `joinDate` varchar(50) DEFAULT NULL,
  `invoiceDate` varchar(50) DEFAULT NULL,
  `deboardDate` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table structure for `invoices` table
CREATE TABLE `invoices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `owner` varchar(255) DEFAULT NULL,
  `party` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `month` varchar(50) DEFAULT NULL,
  `invoiceDate` varchar(50) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `billAmount` varchar(100) DEFAULT NULL,
  `amountReceivable` varchar(100) DEFAULT NULL,
  `amountCredit` varchar(100) DEFAULT NULL,
  `clearanceDate` varchar(50) DEFAULT NULL,
  `invoiceNo` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
